package com.betaCentauri.demoprj.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.betaCentauri.demoprj.entity.CountryEntity;


@Repository("countryRepository")
public interface CountryRepository extends JpaRepository<CountryEntity, Integer> {

}
