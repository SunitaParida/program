package com.betaCentauri.demoprj.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//entity is the table
@Entity
@Table(name = "country")

public class CountryEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "inCountryId")
	private Integer inCountryId;
	
	@Column(name=" varCountryName")
	private String varCountryName ;
	
	@Column(name=" varCountryDescription")
	private String varCountryDescription ;
	
	@Column(name=" varStatus")
	private String varStatus ;

	public Integer getInCountryId() {
		return inCountryId;
	}

	public void setInCountryId(Integer inCountryId) {
		this.inCountryId = inCountryId;
	}

	public String getVarCountryName() {
		return varCountryName;
	}

	public void setVarCountryName(String varCountryName) {
		this.varCountryName = varCountryName;
	}

	public String getVarCountryDescription() {
		return varCountryDescription;
	}

	public void setVarCountryDescription(String varCountryDescription) {
		this.varCountryDescription = varCountryDescription;
	}

	public String getVarStatus() {
		return varStatus;
	}

	public void setVarStatus(String varStatus) {
		this.varStatus = varStatus;
	}
	
	
	
}
