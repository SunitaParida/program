package com.betaCentauri.demoprj.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//entity is the table
@Entity
@Table(name = "designation")

public class DesignationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "intDesignationId")
	private Integer intDesignationId;
	
	@Column(name=" varDesignationName")
	private String varDesignationName ;
	
	@Column(name=" varDesignationDescription")
	private String varDesignationDescription ;
	
	@Column(name=" varStatus")
	private String varStatus ;

	public Integer getIntDesignationId() {
		return intDesignationId;
	}

	public void setIntDesignationId(Integer intDesignationId) {
		this.intDesignationId = intDesignationId;
	}

	public String getVarDesignationName() {
		return varDesignationName;
	}

	public void setVarDesignationName(String varDesignationName) {
		this.varDesignationName = varDesignationName;
	}

	public String getVarDesignationDescription() {
		return varDesignationDescription;
	}

	public void setVarDesignationDescription(String varDesignationDescription) {
		this.varDesignationDescription = varDesignationDescription;
	}

	public String getVarStatus() {
		return varStatus;
	}

	public void setVarStatus(String varStatus) {
		this.varStatus = varStatus;
	}
	
	
}
