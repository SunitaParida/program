package com.betaCentauri.demoprj.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//entity is the table
@Entity
@Table(name = "employee")

public class EmployeeEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "intEmpId")
	private Integer intEmpId;
	
	@Column(name=" varFullName")
	private String varFullName ;
	
	@Column(name="varLastName")
	private String varLastName ;
	
	@Column(name=" varUserName")
	private String varUserName;
	
	@Column(name="varEmail")
	private String varEmail;
	
	@Column(name="varDob")
	private String varDob;
	
	@Column(name="varPhNo")
	private String varPhNo;
	
	@Column(name="varGender ")
	private String varGender;
	
	@Column(name="intDesignation ")
	private Integer intDesignation;
	
	@Column(name="intCountry ")
	private Integer intCountry;
	
	@Column(name=" intState")
	private Integer intState;
	
	@Column(name=" varAddrs")
	private String varAddrs ;
	
	@Column(name="varProfile")
	private String varProfile ;
	
	@Column(name="varPassword ")
	private String varPassword;

	public Integer getIntEmpId() {
		return intEmpId;
	}

	public void setIntEmpId(Integer intEmpId) {
		this.intEmpId = intEmpId;
	}

	public String getVarFullName() {
		return varFullName;
	}

	public void setVarFullName(String varFullName) {
		this.varFullName = varFullName;
	}

	public String getVarLastName() {
		return varLastName;
	}

	public void setVarLastName(String varLastName) {
		this.varLastName = varLastName;
	}

	public String getVarUserName() {
		return varUserName;
	}

	public void setVarUserName(String varUserName) {
		this.varUserName = varUserName;
	}

	public String getVarEmail() {
		return varEmail;
	}

	public void setVarEmail(String varEmail) {
		this.varEmail = varEmail;
	}

	public String getVarDob() {
		return varDob;
	}

	public void setVarDob(String varDob) {
		this.varDob = varDob;
	}

	public String getVarPhNo() {
		return varPhNo;
	}

	public void setVarPhNo(String varPhNo) {
		this.varPhNo = varPhNo;
	}

	public String getVarGender() {
		return varGender;
	}

	public void setVarGender(String varGender) {
		this.varGender = varGender;
	}

	public Integer getIntDesignation() {
		return intDesignation;
	}

	public void setIntDesignation(Integer intDesignation) {
		this.intDesignation = intDesignation;
	}

	public Integer getIntCountry() {
		return intCountry;
	}

	public void setIntCountry(Integer intCountry) {
		this.intCountry = intCountry;
	}

	public Integer getIntState() {
		return intState;
	}

	public void setIntState(Integer intState) {
		this.intState = intState;
	}

	public String getVarAddrs() {
		return varAddrs;
	}

	public void setVarAddrs(String varAddrs) {
		this.varAddrs = varAddrs;
	}

	public String getVarProfile() {
		return varProfile;
	}

	public void setVarProfile(String varProfile) {
		this.varProfile = varProfile;
	}

	public String getVarPassword() {
		return varPassword;
	}

	public void setVarPassword(String varPassword) {
		this.varPassword = varPassword;
	}

	

	
}
