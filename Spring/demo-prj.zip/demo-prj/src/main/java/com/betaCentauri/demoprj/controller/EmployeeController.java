package com.betaCentauri.demoprj.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.betaCentauri.demoprj.employeebean.Employee;
import com.betaCentauri.demoprj.employeebean.Country;
import com.betaCentauri.demoprj.employeebean.Designation;
import com.betaCentauri.demoprj.entity.CountryEntity;
import com.betaCentauri.demoprj.entity.DesignationEntity;
import com.betaCentauri.demoprj.entity.EmployeeEntity;
import com.betaCentauri.demoprj.repository.CountryRepository;
import com.betaCentauri.demoprj.repository.DesignationRepository;
import com.betaCentauri.demoprj.repository.EmployeeRepository;

@Controller
public class EmployeeController {
	
	@Value("${employee.profile.path}")
	private String profilePath;
	
@GetMapping(value="/registration")
public String employeeRegistration(Model model)
{
	List<Map<String,String>> designation = getDesination();
	 model.addAttribute("Designation",designation);
	 List<Map<String,String>> countryList = getCountryList();
	 model.addAttribute("CountryList",countryList);
	 return "thymeleaf/Employee/registration";

}

public List<Map<String,String>> getDesination()
{
	List<Map<String,String>> designation =  new ArrayList();
	Map<String, String> design =  new HashMap<String, String>();
	design.put("Id", "1");
	design.put("Value", "Software Engineer");
	designation.add(design);
	design =  new HashMap<String, String>();
	design.put("Id", "2");
	design.put("Value", "Sytem Engineer");
	designation.add(design);
	design =  new HashMap<String, String>();
	design.put("Id", "3");
	design.put("Value", "Delivery Manager");
	designation.add(design);
	design =  new HashMap<String, String>();
	design.put("Id", "4");
	design.put("Value", "Vice President");
	designation.add(design);
	
	design =  new HashMap<String, String>();
	design.put("Id", "5");
	design.put("Value", "Trainee Engineer");
	designation.add(design);
	
	return designation;
}

@PostMapping("/getStatesList")
@ResponseBody
//@RequestBody calling in ajax case
public List<Map<String,String>> getStateList(@RequestBody Employee employee)
{
	List<Map<String,String>> states = getStateListInfo(employee.getCountry());
	return states;
}

public List<Map<String,String>> getCountryList()
{
	List<Map<String,String>> countryList =  new ArrayList();
	Map<String, String> country =  new HashMap<String, String>();
	country.put("Id", "1");
	country.put("Value", "India");
	countryList.add(country);
	country =  new HashMap<String, String>();
	country.put("Id", "2");
	country.put("Value", "USA");
	countryList.add(country);
	country =  new HashMap<String, String>();
	country.put("Id", "3");
	country.put("Value", "France");
	countryList.add(country);
	country =  new HashMap<String, String>();
	country.put("Id", "4");
	country.put("Value", "UK");
	countryList.add(country);
	
	country =  new HashMap<String, String>();
	country.put("Id", "5");
	country.put("Value", "Germany");
	countryList.add(country);
	
	country =  new HashMap<String, String>();
	country.put("Id", "6");
	country.put("Value", "Russia");
	countryList.add(country);
	
	return countryList;
}

public List<Map<String,String>> getStateListInfo(Integer countryId)
{
	List<Map<String,String>> states = new ArrayList();
	Map<String, String> state =  new HashMap<String, String>();
	if(countryId == 1)// india
	{
		state =  new HashMap<String, String>();
		state.put("Id", "1");
		state.put("Value", "Odiha");
		states.add(state);
		
		state =  new HashMap<String, String>();
		state.put("Id", "2");
		state.put("Value", "Uttar Pradesh");
		states.add(state);
		
	}
	if(countryId == 2)// USA
	{
		state =  new HashMap<String, String>();
		state.put("Id", "3");
		state.put("Value", "Alabama");
		states.add(state);
		
		state =  new HashMap<String, String>();
		state.put("Id", "4");
		state.put("Value", "Washington");
		states.add(state);
	}
	
	if(countryId == 3)// france
	{
		state =  new HashMap<String, String>();
		state.put("Id", "1");
		state.put("Value", "Auvergne ");
		states.add(state);
		
		state =  new HashMap<String, String>();
		state.put("Id", "2");
		state.put("Value", "Bretagne ");
		states.add(state);
		
	}
	
	if(countryId == 4)// Uk
	{
		state =  new HashMap<String, String>();
		state.put("Id", "1");
		state.put("Value", "England ");
		states.add(state);
		
		state =  new HashMap<String, String>();
		state.put("Id", "2");
		state.put("Value", "Scotland ");
		states.add(state);
		
	}
	if(countryId == 5)// germany
	{
		state =  new HashMap<String, String>();
		state.put("Id", "1");
		state.put("Value", "Bavaria ");
		states.add(state);
		
		state =  new HashMap<String, String>();
		state.put("Id", "2");
		state.put("Value", "Brandenburg ");
		states.add(state);
		
	}
	if(countryId == 6)// russia
	{
		state =  new HashMap<String, String>();
		state.put("Id", "1");
		state.put("Value", "Bavaria ");
		states.add(state);
		
		state =  new HashMap<String, String>();
		state.put("Id", "2");
		state.put("Value", "Brandenburg ");
		states.add(state);
		
	}
	
	return states;
}


@Autowired // This means to get the bean called userRepository
// Which is auto-generated by Spring, we will use it to handle the data
private EmployeeRepository employeeRepository;


@PostMapping("/saveEmployeeData")
public @ResponseBody String saveEmployeeData(Employee employee, Model model, @RequestParam("profile") MultipartFile files)throws IllegalStateException, IOException
{
	System.out.println(profilePath);
	System.out.println(employee.toString());
	List<Map<String,String>> designation = getDesination();
	 model.addAttribute("Designation",designation);
	 List<Map<String,String>> countryList = getCountryList();
	 model.addAttribute("CountryList",countryList);
	 
	 //save data
	 EmployeeEntity emp=new EmployeeEntity();
	 emp.setVarFullName(employee.getFullName());
	 emp.setVarLastName(employee.getLastName());
	 emp.setVarUserName(employee.getUserName());
	 emp.setVarEmail(employee.getEmail());
	 emp.setVarDob(employee.getDob());
	 emp.setVarPhNo(employee.getPhoto());
	 emp.setVarGender(employee.getGender());
	 emp.setIntDesignation(employee.getDesignation());
	 emp.setIntCountry(employee.getCountry());
	 emp.setIntState(employee.getState());
	 emp.setVarAddrs(employee.getAddress());;
	emp.setVarProfile(profilePath+files.getOriginalFilename());
	 emp.setVarPassword(employee.getPassword());
	employeeRepository.save(emp);
	 
	 files.transferTo(new File(profilePath+files.getOriginalFilename()));
	 model.addAttribute("IsSuccess",true);
	 model.addAttribute("UserName",employee.getUserName());
	return "thymeleaf/Employee/registration";

}

@Autowired // This means to get the bean called userRepository
// Which is auto-generated by Spring, we will use it to handle the data
private DesignationRepository designationRepository;

@PostMapping("/saveDesignation")
public @ResponseBody String saveDesignation(Designation designation)throws IllegalStateException, IOException
{
	
	 
	 //save data
	 DesignationEntity des=new DesignationEntity();
	 des.setVarDesignationName(designation.getDesignationNm());
	 des.setVarDesignationDescription(designation.getDescription());
	 des.setVarStatus(designation.getStatus());
	designationRepository.save(des);
	 
	 
	return "thymeleaf/Employee/designation";

}

@Autowired // This means to get the bean called userRepository
//Which is auto-generated by Spring, we will use it to handle the data
private CountryRepository countryRepository;

@PostMapping("/saveCountry")
public @ResponseBody String saveCountry(Country country)throws IllegalStateException, IOException
{
	
	 
	 //save data
	 CountryEntity co=new CountryEntity();
	co.setVarCountryName(country.getCountry());
	co.setVarCountryDescription(country.getDescription());
	co.setVarStatus(country.getStatus());
	countryRepository.save(co);
	 
	 
	return "thymeleaf/Employee/country";

}

@GetMapping(value = "/designation")
public String Designation()
{
	return "thymeleaf/Employee/Designation";
}

@GetMapping(value = "/country")
public String country()
{
	return "thymeleaf/Employee/country";
}

@GetMapping(value = "/state")
public String state()
{
	return "thymeleaf/Employee/state";
}
}
