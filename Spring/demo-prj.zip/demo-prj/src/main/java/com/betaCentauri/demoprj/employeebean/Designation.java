package com.betaCentauri.demoprj.employeebean;

public class Designation {
private String designationNm;
private String description;
private String status;
public String getDesignationNm() {
	return designationNm;
}
public void setDesignationNm(String designationNm) {
	this.designationNm = designationNm;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Designation [designationNm=" + designationNm + ", description=" + description + ", status=" + status + "]";
}


}
