$(document).ready(function() {

	$("#country").change(function() {
		var countryId = $(this).val();
		var countryName = $("#country option:selected").text();

		var country = {
			"country" : countryId
		};

		$.ajax({
			type : 'POST',
			contentType : "application/json",
			url : "getStatesList",
			data : JSON.stringify(country),
			dataType : "json",
			success : function(data) {
				
				var states = "<option value='-1'>-- Select State -- </option>";
				for(i=0;i<data.length;i++)
					{
					states += "<option value='"+data[i].Id+"'>"+data[i].Value+"</option>";
					}
				
				$("#state").html(states);
				
			},
			error : function(data) {
				alert('failure');
			}
		});

	});

});