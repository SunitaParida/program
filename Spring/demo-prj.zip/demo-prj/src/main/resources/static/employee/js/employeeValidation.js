
function validate(form){
/*var name=document.getElementById("fullName").value;
    
    if(name==null || name==""){
        alert("Please enter your First name");
        document.getElementById("name").select();
        return false;
    }
	
	 if (!/^[a-z A-Z]*$/g.test(document.val.fullName.value)) {
	        alert("please enter characters only for First name");
	        document.getElementById("fullName").select();
	        return false;
	    }
	 
	 var lname=document.getElementById("lastName").value;
	    
	    if(lname==null || lname==""){
	        alert("Please enter  your last name");
	        document.getElementById("lastName").select();
	        return false;
	    }
	    
	 if (!/^[a-z A-Z]*$/g.test(document.val.lastName.value)) {
	        alert("please enter characters only for last name");
	        document.getElementById("lastName").select();
	        return false;
	    }
	 
	 var userName=document.getElementById("userName").value;
	 
	 if(userName==null || userName==""){
	        alert("Please enter userName");
	        document.getElementById("userName").select();
	        return false;
	    }
	 re = /[0-9]/;
     if(!re.test(userName)) {
       alert("Error: userName must contain at least one number (0-9)!");
       document.getElementById("userName").select();
       return false;
     }
     re = /[a-z]/;
     if(!re.test(userName)) {
       alert("Error: userName must contain at least one lowercase letter (a-z)!");
       document.getElementById("userName").select();
       return false;
     }
     re = /[A-Z]/;
     if(!re.test(userName)) {
       alert("Error: userName must contain at least one uppercase letter (A-Z)!");
       document.getElementById("userName").select();
       return false;
     }
	 
	    if (document.val.email.value==null || document.val.email.value=="") {
            alert("Please enter correct email ID")
            document.getElementById("email").select();
            return false;
         }
         
	    if (document.val.dob.value==null || document.val.dob.value=="") {
	          alert("Please enter ur dob");
	          document.getElementById("dob").select();
	          return false;
	       }
	    
		
		var chkdate = document.getElementById("dob").value;
		
	    var cdate= new Date(chkdate);
	    var today=new Date();
	    today.setHours(0,0,0,0);
	    if(cdate>=today)
	    {
			alert("current date or future date can't be taken..Plz try again");
			document.getElementById("dob").select();
			return false;}
	    
	  var birthyr= parseInt(chkdate, 10);
	  var today = new Date();
	  var year=today.getFullYear();
	   var age=year-birthyr;
	 
	  if ( age < 18)
	  { 
	    alert(birthyr+" " + age+"The age must be greater than 18"+year);
		document.getElementById("dob").select();

	    return false;
	  }
	    
	    
	    var mob=document.getElementById("number").value;
		if ( mob.length!=10) 
					
				{
					alert("please enter 10 digit mobile number");
					document.getElementById("number").select();
					return false;}
		

	    if (!/^[0-9]+$/.test(mob)) {
	        alert("please enter numbers only for ph no");
	        document.getElementById("number").select();
	        return false;
	    }
	         
	    
	  if (document.val.gender.value==null || document.val.gender.value=="") {
         alert("Please select gender");
         
         return false;
      }
	
	  var e = document.getElementById("designation");
	 	var designation = e.options[e.selectedIndex].value;

	 	
	 	if(designation==-1)
	 	{
	 	alert("Please select ur designation");
	 	document.val.focus();
	 	return false;
	 	}
		
	 	var e = document.getElementById("country");
	 	var country = e.options[e.selectedIndex].value;

	 	
	 	if(country==-1)
	 	{
	 	alert("Please select ur country");
	 	document.val.focus();
	 	return false;
	 	}
	 	
	 	var e = document.getElementById("state");
	 	var state = e.options[e.selectedIndex].value;

	 	
	 	if(state==-1)
	 	{
	 	alert("Please select ur state");
	 	document.val.focus();
	 	return false;
	 	}
	 */	
   
	if(document.val.address.value==null || document.val.address.value=="")
	{
		alert("please provide your address details");
		document.getElementById("address").select();
		return false;}

	var fup = document.getElementById('photo');
    var fileName = fup.value;
    var ext = fileName.substring(fileName.lastIndexOf('.') + 1);

if(!(ext =="JPG" || ext=="jpg" || ext=="PNG" || ext=="png" || ext=="JPEG" || ext=="jpeg"))
{
	 alert("Please Upload the file with extension jpg or jpeg or png");
    return false;
}

	
	 var passw=document.getElementById("pass").value;
	      if(passw.length < 8 || passw.length > 15 ) {
	        alert("Error: Password must contain more than or equal to 8 character and less than or equal to 15 character!!");
	        document.getElementById("pass").select();
	        
	        return false;
	      }
	     
	      re = /[0-9]/;
	      if(!re.test(passw)) {
	        alert("Error: password must contain at least one number (0-9)!");
	        document.getElementById("pass").select();
	        return false;
	      }
	      re = /[a-z]/;
	      if(!re.test(passw)) {
	        alert("Error: password must contain at least one lowercase letter (a-z)!");
	        document.getElementById("pass").select();
	        return false;
	      }
	      re = /[A-Z]/;
	      if(!re.test(passw)) {
	        alert("Error: password must contain at least one uppercase letter (A-Z)!");
	        document.getElementById("pass").select();
	        return false;
	      }
	      
	      var regularExpression  = /[!@#$%^&*]/;
	      if(!regularExpression.test(passw)) {
	          alert("password should contain atleast one special character!");
	          return false;
	      }
	      
	      if (document.val.cpass.value==null || document.val.cpass.value=="") {
	            alert("Please enter the confirm password");
	            document.getElementById("cpass").select();
	            return false;
	         }
	      var cpassw=document.getElementById("cpass").value;
	      if(!(passw==cpassw))
	    	  {
	    	  
	    	  alert("confirm password must be same with above password");
	    	  document.getElementById("cpass").select();
	    	  return false;
	    	  }	

	      }
