package com.betaCentauri.demoprj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPrjApplicationTests {

	@Test
	void contextLoads() {
	}

}
